from mcp_servers.weather_server import DEMO_WEATHER
from mcp_servers.agriculture_server import DATA

def infer_context(q):
    q=q.lower(); crop="beans" if "bean" in q else "maize"
    location=next((x for x in ["Musanze","Kigali","Bugesera"] if x.lower() in q),"Musanze")
    soil=30.0
    for n in [20,25,30,35,40,45,50,55,60,65,70]:
        if f"{n}%" in q: soil=float(n)
    return {"crop":crop,"location":location,"soil_moisture_percent":soil}

def run_agent(question):
    c=infer_context(question)
    weather={"location":c["location"],**DEMO_WEATHER.get(c["location"],DEMO_WEATHER["Musanze"])}
    info=DATA[c["crop"]]
    crop={**c,"minimum_soil_moisture_percent":info["minimum_soil_moisture_percent"],"optimal_soil_moisture_percent":info["optimal_soil_moisture_percent"],"typical_daily_water_need_mm":info["typical_daily_water_need_mm"],"irrigation_needed_by_soil":c["soil_moisture_percent"]<info["minimum_soil_moisture_percent"]}
    if crop["irrigation_needed_by_soil"] and weather["rainfall_next_3_days_mm"]<5:
        rec=f"Irrigation is recommended for the {c['crop']} field in {c['location']} based on the demonstration data. Soil moisture is {c['soil_moisture_percent']}%, below the prototype minimum threshold of {info['minimum_soil_moisture_percent']}%, and only {weather['rainfall_next_3_days_mm']} mm of rain is expected over 3 days."
    elif crop["irrigation_needed_by_soil"]:
        rec=f"Monitor the {c['crop']} field. Soil moisture is low, but about {weather['rainfall_next_3_days_mm']} mm of rain is expected over 3 days. Reassess before irrigating."
    else: rec=f"No immediate irrigation is indicated by the prototype threshold. Assumed soil moisture is {c['soil_moisture_percent']}%."
    return {"question":question,"context":c,"tool_calls":[{"server":"Weather MCP Server","tool":"get_weather","result":weather},{"server":"Agriculture MCP Server","tool":"get_crop_water_requirement","result":crop}],"recommendation":rec,"disclaimer":"Demonstration prototype using sample data; not production agronomic advice."}
