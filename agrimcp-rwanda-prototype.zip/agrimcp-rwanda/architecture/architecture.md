# AgriMCP Rwanda Architecture

```text
Farmer / Extension Worker
        |
Web / Mobile Interface
        |
AgriMCP Agent
        |
LLM / Reasoning + Planning
        |
MCP Client
   _____|________________
  |          |           |
Weather MCP  Agriculture  Future Pest/Soil/Market MCP
Server       MCP Server   Servers
  |          |
Weather API  Crop/Agronomy Data
  |__________|
       |
Information Synthesis
       |
Actionable Recommendation
       |
Human decision + feedback
```

The current MVP uses two MCP server implementations and a lightweight local adapter so the workflow can be tested without external services. The production architecture should use direct MCP client sessions and validated Rwanda-specific APIs/datasets.

Human-in-the-loop: the farmer or extension officer remains the decision-maker. The prototype does not autonomously control farm equipment.
