# AgriMCP Rwanda 🌱

AgriMCP Rwanda is an MVP agentic AI agricultural decision-support system for smallholder farmers in Rwanda.

## Workflow
Farmer question → Agent context understanding → MCP tools → data retrieval → reasoning → actionable recommendation.

## MVP
The prototype demonstrates an irrigation decision for maize using two MCP servers:
- Weather MCP Server: `get_weather(location)`
- Agriculture MCP Server: `get_crop_water_requirement(crop, soil_moisture_percent)`

The current data is **demonstration data**, not production agronomic advice. The next stage is to connect validated Rwanda-specific datasets and live APIs.

## Stack
Python 3.11+, FastAPI, Uvicorn, Pydantic, MCP Python SDK, HTML/CSS/JavaScript.

## Run on Windows
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000
API docs: http://127.0.0.1:8000/docs

## Example
Ask: `Should I irrigate my maize field in Musanze? My soil moisture is 30%.`

The interface shows the agent context, MCP tool calls, and recommendation.

## Roadmap
1. Direct MCP client sessions
2. Live weather API
3. Rwanda crop/soil datasets
4. Pest and disease MCP server
5. Farmer memory/profile
6. Kinyarwanda text and voice
7. Extension-officer human-in-the-loop review
8. Public deployment
