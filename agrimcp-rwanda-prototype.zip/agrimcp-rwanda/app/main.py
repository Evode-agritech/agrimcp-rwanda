from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from agent.agent import run_agent
app=FastAPI(title="AgriMCP Rwanda",version="0.1.0")
class Question(BaseModel): question:str
HTML='''<!doctype html><html><head><meta charset="utf-8"><title>AgriMCP Rwanda</title><style>body{font-family:Arial;max-width:900px;margin:40px auto;padding:20px;background:#f4f7f4}.card{background:white;padding:25px;border-radius:14px;margin:15px 0}textarea{width:100%;height:100px;padding:10px;box-sizing:border-box}button{padding:12px 20px;margin-top:10px;background:#176b40;color:white;border:0;border-radius:7px}pre{white-space:pre-wrap;background:#f0f2f0;padding:12px}</style></head><body><div class="card"><h1>🌱 AgriMCP Rwanda</h1><p>Agentic AI agricultural decision-support MVP</p><textarea id="q">Should I irrigate my maize field in Musanze? My soil moisture is 30%.</textarea><br><button onclick="ask()">Ask AgriMCP Agent</button></div><div class="card" id="r" style="display:none"><h2>Recommendation</h2><p id="rec"></p><h3>Agent context</h3><pre id="ctx"></pre><h3>MCP tool calls</h3><pre id="tools"></pre><small id="disc"></small></div><script>async function ask(){let q=document.getElementById('q').value;let x=await fetch('/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q})});let d=await x.json();document.getElementById('r').style.display='block';rec.innerText=d.recommendation;ctx.innerText=JSON.stringify(d.context,null,2);tools.innerText=JSON.stringify(d.tool_calls,null,2);disc.innerText=d.disclaimer}</script></body></html>'''
@app.get('/',response_class=HTMLResponse)
def home(): return HTML
@app.post('/ask')
def ask(q:Question): return run_agent(q.question)
@app.get('/health')
def health(): return {"status":"ok"}
