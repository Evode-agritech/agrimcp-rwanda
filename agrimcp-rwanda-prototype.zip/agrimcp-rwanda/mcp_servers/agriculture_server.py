from mcp.server.fastmcp import FastMCP
import json
from pathlib import Path
mcp=FastMCP("AgriMCP Agriculture")
with open(Path(__file__).resolve().parents[1]/"data"/"crop_data.json",encoding="utf-8") as f: DATA=json.load(f)
@mcp.tool()
def get_crop_water_requirement(crop:str,soil_moisture_percent:float)->dict:
    info=DATA.get(crop.lower())
    if not info: return {"error":f"No data for {crop}"}
    return {"crop":crop.lower(),"soil_moisture_percent":soil_moisture_percent,**info,"irrigation_needed_by_soil":soil_moisture_percent<info["minimum_soil_moisture_percent"]}
if __name__=="__main__": mcp.run()
