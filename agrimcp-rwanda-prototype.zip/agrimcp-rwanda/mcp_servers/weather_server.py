from mcp.server.fastmcp import FastMCP
mcp = FastMCP("AgriMCP Weather")
DEMO_WEATHER={"Musanze":{"temperature_c":22,"rainfall_next_24h_mm":1,"rainfall_next_3_days_mm":3,"condition":"Mostly dry"},"Kigali":{"temperature_c":25,"rainfall_next_24h_mm":2,"rainfall_next_3_days_mm":8,"condition":"Partly cloudy"},"Bugesera":{"temperature_c":27,"rainfall_next_24h_mm":0,"rainfall_next_3_days_mm":2,"condition":"Dry"}}
@mcp.tool()
def get_weather(location:str)->dict:
    return {"location":location,**DEMO_WEATHER.get(location.title(),DEMO_WEATHER["Musanze"])}
if __name__=="__main__": mcp.run()
