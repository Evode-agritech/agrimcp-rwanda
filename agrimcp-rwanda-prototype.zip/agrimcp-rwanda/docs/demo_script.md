# Short Demo Script

1. Introduce: “AgriMCP Rwanda is an agentic AI agricultural decision-support prototype for smallholder farmers.”
2. Enter: “Should I irrigate my maize field in Musanze? My soil moisture is 30%.”
3. Click **Ask AgriMCP Agent**.
4. Show the recommendation.
5. Show the context: crop, location, soil moisture.
6. Show the two MCP tool calls: weather and crop-water requirement.
7. Explain: “The agent retrieves information from separate tools, synthesizes it, and produces an actionable recommendation.”
8. Show the architecture diagram and mention future live APIs, Rwanda data, Kinyarwanda, and extension-worker review.
